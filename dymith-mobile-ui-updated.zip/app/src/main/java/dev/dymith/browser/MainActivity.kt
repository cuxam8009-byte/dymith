package dev.dymith.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.os.SystemClock
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.ViewTreeObserver
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import java.io.ByteArrayInputStream
import java.util.Locale

/**
 * Dymith Phase 0: một tab, WebView hệ thống + lõi Rust + thanh công cụ kính.
 * Vỏ dùng View thuần (không AppCompat/Compose) để APK nhỏ và khởi động nhanh.
 */
class MainActivity : Activity() {

    private companion object {
        const val SEARCH_TEMPLATE = "https://www.google.com/search?q=%s"
        const val PREF_BLUR = "glass_blur"
        const val PREF_KB_TEXT = "kb_text"
        const val PREF_UA_CLEAN = "ua_clean"
        const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private lateinit var progressBar: View
    private lateinit var bar: FrameLayout
    private lateinit var tint: View
    private lateinit var omnibox: EditText
    private lateinit var btnBack: ImageButton
    private lateinit var btnReload: ImageButton
    private lateinit var btnMenu: ImageButton

    private var glass: GlassBackdrop? = null
    private var frameStats: FrameStats? = null

    private var defaultUa: String = ""
    private var loading = false
    private var barHidden = false
    private var insetTop = 0
    private var insetBottom = 0
    private var insetLeft = 0
    private var insetRight = 0

    private var firstDrawMs = -1L
    private var onCreateMs = 0.0
    private var webViewCreateMs = 0.0

    // ------------------------------------------------------------------ vòng đời

    override fun onCreate(savedInstanceState: Bundle?) {
        val t0 = SystemClock.elapsedRealtimeNanos()
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("dymith", MODE_PRIVATE)
        Core.load()

        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        buildUi()
        setContentView(root)

        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightStatusBars = true
        controller.isAppearanceLightNavigationBars = true

        applyGlassMode()
        applyUserAgentMode()

        val stats = FrameStats(window)
        stats.budgetUs = budgetFromDisplay()
        stats.start()
        frameStats = stats

        root.viewTreeObserver.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                root.viewTreeObserver.removeOnPreDrawListener(this)
                firstDrawMs = SystemClock.elapsedRealtime() - Process.getStartElapsedRealtime()
                return true
            }
        })

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState)
        } else if (!handleIntent(intent)) {
            loadStartPage()
        }
        onCreateMs = (SystemClock.elapsedRealtimeNanos() - t0) / 1_000_000.0
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onPause() {
        web.onPause()
        super.onPause()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onDestroy() {
        frameStats?.stop()
        root.removeView(web)
        web.destroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (omnibox.hasFocus()) {
            omnibox.clearFocus()
            hideKeyboard()
        } else if (web.canGoBack()) {
            web.goBack()
        } else {
            super.onBackPressed()
        }
    }

    private fun handleIntent(i: Intent?): Boolean {
        if (i == null || i.action != Intent.ACTION_VIEW) return false
        val data = i.data ?: return false
        web.loadUrl(data.toString())
        return true
    }

    // ------------------------------------------------------------------ giao diện

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun budgetFromDisplay(): Int {
        @Suppress("DEPRECATION")
        val hz = windowManager.defaultDisplay.refreshRate
        return if (hz > 1f) (1_000_000f / hz).toInt() else 16_667
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildUi() {
        root = FrameLayout(this)

        val tw = SystemClock.elapsedRealtimeNanos()
        web = WebView(this)
        webViewCreateMs = (SystemClock.elapsedRealtimeNanos() - tw) / 1_000_000.0
        configureWebView()
        root.addView(web, FrameLayout.LayoutParams(MATCH, MATCH))

        progressBar = View(this)
        progressBar.setBackgroundColor(0xFF6B5CE7.toInt())
        progressBar.pivotX = 0f
        progressBar.scaleX = 0f
        progressBar.visibility = View.INVISIBLE
        val progressParams = FrameLayout.LayoutParams(MATCH, dp(3))
        progressParams.gravity = Gravity.TOP
        root.addView(progressBar, progressParams)

        // Thanh công cụ dạng viên thuốc, nổi ở đáy màn hình.
        bar = FrameLayout(this)
        bar.clipToOutline = true
        bar.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, view.height / 2f)
            }
        }

        if (Build.VERSION.SDK_INT >= 31) {
            val g = GlassBackdrop(this)
            g.source = web
            g.setBlurRadiusPx(dp(18).toFloat())
            glass = g
            bar.addView(g, FrameLayout.LayoutParams(MATCH, MATCH))
        }

        tint = View(this)
        bar.addView(tint, FrameLayout.LayoutParams(MATCH, MATCH))

        btnBack = iconButton(R.drawable.ic_search, "Tìm kiếm") {
            omnibox.requestFocus()
            omnibox.setSelection(omnibox.text.length)
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(omnibox, InputMethodManager.SHOW_IMPLICIT)
        }
        btnReload = iconButton(R.drawable.ic_refresh, "Tải lại") {
            if (loading) web.stopLoading() else web.reload()
        }
        btnMenu = iconButton(R.drawable.ic_more, "Menu") { anchor -> showMenu(anchor) }
        omnibox = buildOmnibox()

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(8), 0, dp(8), 0)
        row.addView(btnBack, LinearLayout.LayoutParams(dp(42), dp(44)))
        row.addView(omnibox, LinearLayout.LayoutParams(0, dp(44), 1f))
        row.addView(btnReload, LinearLayout.LayoutParams(dp(40), dp(44)))
        row.addView(btnMenu, LinearLayout.LayoutParams(dp(40), dp(44)))
        bar.addView(row, FrameLayout.LayoutParams(MATCH, MATCH))

        val barParams = FrameLayout.LayoutParams(MATCH, dp(60))
        barParams.gravity = Gravity.BOTTOM
        barParams.setMargins(dp(14), 0, dp(14), dp(10))
        bar.elevation = dp(10).toFloat()
        root.addView(bar, barParams)

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val sys = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            insetTop = sys.top
            insetLeft = sys.left
            insetRight = sys.right
            insetBottom = maxOf(sys.bottom, ime.bottom)
            applyInsets()
            insets
        }
        updateBackButton()
    }

    private fun applyInsets() {
        (web.layoutParams as FrameLayout.LayoutParams).topMargin = insetTop
        web.requestLayout()
        (progressBar.layoutParams as FrameLayout.LayoutParams).topMargin = insetTop
        progressBar.requestLayout()
        val lp = bar.layoutParams as FrameLayout.LayoutParams
        lp.leftMargin = dp(12) + insetLeft
        lp.rightMargin = dp(12) + insetRight
        lp.bottomMargin = dp(12) + insetBottom
        bar.requestLayout()
    }

    private fun iconButton(res: Int, desc: String, onClick: (View) -> Unit): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.setBackgroundColor(Color.TRANSPARENT)
        b.scaleType = ImageView.ScaleType.CENTER_INSIDE
        b.setPadding(dp(11), dp(11), dp(11), dp(11))
        b.imageTintList = ColorStateList.valueOf(0xFF1C1C1E.toInt())
        b.contentDescription = desc
        b.setOnClickListener { v -> onClick(v) }
        return b
    }

    private fun omniboxInputType(): Int {
        return if (prefs.getBoolean(PREF_KB_TEXT, false)) {
            InputType.TYPE_CLASS_TEXT
        } else {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
    }

    private fun buildOmnibox(): EditText {
        val e = EditText(this)
        e.setSingleLine(true)
        e.hint = "Tìm kiếm hoặc nhập địa chỉ web"
        e.setHintTextColor(0x99000000.toInt())
        e.setTextColor(0xFF111111.toInt())
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        e.background = null
        e.gravity = Gravity.CENTER_VERTICAL
        e.setPadding(dp(8), 0, dp(8), 0)
        e.imeOptions = EditorInfo.IME_ACTION_GO or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        e.inputType = omniboxInputType()
        e.setSelectAllOnFocus(true)
        e.setOnEditorActionListener { v, actionId, event ->
            val enter = event != null &&
                event.keyCode == KeyEvent.KEYCODE_ENTER &&
                event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE || enter) {
                go(v.text.toString())
                true
            } else {
                false
            }
        }
        e.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) showBar()
        }
        return e
    }

    private fun tintDrawable(blurOn: Boolean): GradientDrawable {
        val d = GradientDrawable()
        d.shape = GradientDrawable.RECTANGLE
        d.cornerRadius = dp(30).toFloat()
        if (blurOn) {
            // Kính thật: nền mờ phía sau, chỉ phủ một lớp trắng mỏng.
            d.setColor(0x4DFFFFFF)
            d.setStroke(dp(1), 0x80FFFFFF.toInt())
        } else {
            // Kính nhuộm màu: gần đục để chữ luôn đọc được trên mọi trang.
            d.setColor(0xF2F7F7FA.toInt())
            d.setStroke(dp(1), 0x1F000000)
        }
        return d
    }

    private fun applyGlassMode() {
        val wantBlur = prefs.getBoolean(PREF_BLUR, false)
        val g = glass
        val on = wantBlur && g != null
        if (g != null) g.visibility = if (on) View.VISIBLE else View.GONE
        tint.background = tintDrawable(on)
    }

    private fun hideBar() {
        if (barHidden) return
        barHidden = true
        val lp = bar.layoutParams as FrameLayout.LayoutParams
        bar.animate().translationY((bar.height + lp.bottomMargin + dp(8)).toFloat()).setDuration(180).start()
    }

    private fun showBar() {
        if (!barHidden) return
        barHidden = false
        bar.animate().translationY(0f).setDuration(180).start()
    }

    private fun onWebScrolled(dy: Int) {
        if (omnibox.hasFocus()) return
        if (dy > dp(4)) {
            hideBar()
        } else if (dy < -dp(4)) {
            showBar()
        }
    }

    private fun updateBackButton() {
        btnBack.alpha = 1f
    }

    private fun setLoadingUi(isLoading: Boolean) {
        loading = isLoading
        btnReload.setImageResource(if (isLoading) R.drawable.ic_close else R.drawable.ic_refresh)
        if (!isLoading) progressBar.visibility = View.INVISIBLE
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(omnibox.windowToken, 0)
    }

    // ------------------------------------------------------------------ WebView

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.setSupportMultipleWindows(false)
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.mediaPlaybackRequiresUserGesture = true
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.safeBrowsingEnabled = true
        defaultUa = s.userAgentString ?: ""
        web.setBackgroundColor(Color.WHITE)

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val scheme = request?.url?.scheme?.lowercase(Locale.ROOT) ?: return false
                return if (scheme == "http" || scheme == "https" || scheme == "about" ||
                    scheme == "data" || scheme == "blob"
                ) {
                    false
                } else {
                    toast("Phase 0 chưa mở liên kết kiểu " + scheme)
                    true
                }
            }

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                if (request == null || request.isForMainFrame) return null
                val url = request.url.toString()
                if (!url.startsWith("http")) return null
                return if (Core.shouldBlock(url)) emptyResponse() else null
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                setLoadingUi(true)
                if (url != null && !omnibox.hasFocus()) omnibox.setText(displayUrl(url))
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                setLoadingUi(false)
                updateBackButton()
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                updateBackButton()
                if (url != null && !omnibox.hasFocus()) omnibox.setText(displayUrl(url))
            }

            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                toast("Tiến trình hiển thị đã dừng, đang khởi động lại")
                recreate()
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.visibility = if (newProgress in 1..99) View.VISIBLE else View.INVISIBLE
                progressBar.scaleX = newProgress / 100f
            }
        }

        web.setDownloadListener { _, _, _, _, _ ->
            toast("Tải xuống sẽ có ở Phase 1")
        }

        web.setOnScrollChangeListener { _, _, scrollY, _, oldScrollY ->
            onWebScrolled(scrollY - oldScrollY)
        }
    }

    private fun emptyResponse(): WebResourceResponse {
        return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
    }

    private fun displayUrl(url: String): String {
        if (url.startsWith(StartPage.URL) || url == "about:blank") return ""
        return url.removePrefix("https://").removePrefix("http://").removeSuffix("/")
    }

    private fun loadStartPage() {
        web.loadDataWithBaseURL(StartPage.URL, StartPage.HTML, "text/html", "utf-8", null)
        omnibox.setText("")
    }

    private fun go(raw: String) {
        val url = Core.resolve(raw, SEARCH_TEMPLATE)
        omnibox.clearFocus()
        hideKeyboard()
        if (url == "about:blank") loadStartPage() else web.loadUrl(url)
    }

    private fun cleanUserAgent(ua: String): String {
        var out = ua.replace("; wv)", ")")
        out = out.replace(Regex("Version/\\d+(\\.\\d+)*\\s"), "")
        return out + " Dymith/0.0.1"
    }

    private fun applyUserAgentMode() {
        val clean = prefs.getBoolean(PREF_UA_CLEAN, false)
        web.settings.userAgentString = if (clean) cleanUserAgent(defaultUa) else defaultUa
    }

    // ------------------------------------------------------------------ menu và chẩn đoán

    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        val m = pm.menu
        m.add(0, 1, 0, "Trang chủ")
        val blurItem = m.add(0, 2, 1, "Kính blur thật (thử nghiệm)")
        blurItem.isCheckable = true
        blurItem.isChecked = prefs.getBoolean(PREF_BLUR, false)
        val kbItem = m.add(0, 3, 2, "Bàn phím ô địa chỉ: văn bản")
        kbItem.isCheckable = true
        kbItem.isChecked = prefs.getBoolean(PREF_KB_TEXT, false)
        val uaItem = m.add(0, 4, 3, "UA chuẩn trình duyệt (bỏ wv)")
        uaItem.isCheckable = true
        uaItem.isChecked = prefs.getBoolean(PREF_UA_CLEAN, false)
        m.add(0, 5, 4, "Chẩn đoán và báo cáo")

        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> loadStartPage()
                2 -> toggleBlur()
                3 -> toggleKeyboardMode()
                4 -> toggleUserAgent()
                5 -> showDiagnostics()
            }
            true
        }
        pm.show()
    }

    private fun toggleBlur() {
        if (Build.VERSION.SDK_INT < 31) {
            toast("Kính blur cần Android 12 trở lên")
            return
        }
        val now = !prefs.getBoolean(PREF_BLUR, false)
        prefs.edit().putBoolean(PREF_BLUR, now).apply()
        applyGlassMode()
        toast(if (now) "Đã bật kính blur (thử nghiệm)" else "Đã tắt kính blur")
    }

    private fun toggleKeyboardMode() {
        val now = !prefs.getBoolean(PREF_KB_TEXT, false)
        prefs.edit().putBoolean(PREF_KB_TEXT, now).apply()
        omnibox.inputType = omniboxInputType()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.restartInput(omnibox)
        toast(if (now) "Bàn phím văn bản" else "Bàn phím địa chỉ (URL)")
    }

    private fun toggleUserAgent() {
        val now = !prefs.getBoolean(PREF_UA_CLEAN, false)
        prefs.edit().putBoolean(PREF_UA_CLEAN, now).apply()
        applyUserAgentMode()
        web.reload()
        toast(if (now) "UA chuẩn trình duyệt: bật" else "UA mặc định của WebView")
    }

    private fun showDiagnostics() {
        val g = glass
        val blurOn = prefs.getBoolean(PREF_BLUR, false)
        val glassText = if (g == null) {
            "không hỗ trợ (cần Android 12+)"
        } else {
            (if (blurOn) "blur thật" else "nhuộm màu") +
                ", đã ghi " + g.recordedFrames + " khung, lỗi: " + (g.lastError ?: "không")
        }
        val firstDraw = if (firstDrawMs >= 0) firstDrawMs.toString() + " ms" else "chưa đo"

        val extras = ArrayList<Pair<String, String>>()
        extras.add(Pair("Khung đầu tiên (tính từ lúc tiến trình bắt đầu)", firstDraw))
        extras.add(Pair("Activity.onCreate", String.format(Locale.US, "%.1f ms", onCreateMs)))
        extras.add(Pair("Tạo WebView", String.format(Locale.US, "%.1f ms", webViewCreateMs)))
        extras.add(Pair("Kính", glassText))
        extras.add(Pair("UA chuẩn trình duyệt", prefs.getBoolean(PREF_UA_CLEAN, false).toString()))
        extras.add(Pair("Bàn phím ô địa chỉ", if (prefs.getBoolean(PREF_KB_TEXT, false)) "văn bản" else "URL"))
        extras.add(Pair("User-Agent", web.settings.userAgentString ?: "?"))

        val text = Diagnostics.report(this, frameStats, extras)

        val tv = TextView(this)
        tv.text = text
        tv.typeface = Typeface.MONOSPACE
        tv.textSize = 11f
        tv.setTextIsSelectable(true)
        tv.setPadding(dp(16), dp(8), dp(16), dp(8))
        val sv = ScrollView(this)
        sv.addView(tv)

        AlertDialog.Builder(this)
            .setTitle("Chẩn đoán Dymith")
            .setView(sv)
            .setPositiveButton("Sao chép") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Dymith report", text))
                toast("Đã sao chép báo cáo")
            }
            .setNegativeButton("Đóng", null)
            .show()
    }
}
